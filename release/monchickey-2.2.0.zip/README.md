# 基于 python2.7.x 的常用类库 monchickey 2.2.0 20170623

## 所需依赖
## 1. python-devel 安装:yum -y install python-devel或者rpm包安装
## 2. mysql-devel  安装:yum -y install mysql-devel或者rpm包安装
## 3. MySQL-python 下载地址:https://pypi.python.org/pypi/MySQL-python
## 4. PyYAML 下载地址:https://pypi.python.org/pypi/PyYAML
