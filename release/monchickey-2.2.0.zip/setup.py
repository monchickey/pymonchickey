import sys
from setuptools import setup

longdesc = '''
This is a tool library based on python 2. It is called monchickey.
Features include file handling, database connection acquisition, 
Network communication and simple system command calls, 
The most commonly used for data calculation, filtering and conversion.

Required packages:
    MySQL-python
    PyYAML
'''

setup(
    name="monchickey",
    version='2.2.0',
    description="Commonly used tool library",
    long_description=longdesc,
    author="zengzhiying",
    author_email="yingzhi_zeng@126.com",
    url="https://github.com/zengzhiying/pymonchickey/",
    packages=[
        'monchickey',
        'monchickey.dataprocess',
        'monchickey.database',
        'monchickey.fileprocess',
        'monchickey.networkcommunication',
        'monchickey.ostools'
        ],
    # license='LGPL',
    # platforms='Posix; MacOS X; Windows',
    # classifiers=[
    #     'Development Status :: 5 - Production/Stable',
    #     'Intended Audience :: Developers',
    #     'License :: OSI Approved :: '
    #     'GNU Library or Lesser General Public License (LGPL)',
    #     'Operating System :: OS Independent',
    #     'Topic :: Internet',
    #     'Topic :: Security :: Cryptography',
    #     'Programming Language :: Python',
    #     'Programming Language :: Python :: 2',
    #     'Programming Language :: Python :: 2.6',
    #     'Programming Language :: Python :: 2.7',
    #     'Programming Language :: Python :: 3',
    #     'Programming Language :: Python :: 3.2',
    #     'Programming Language :: Python :: 3.3',
    #     'Programming Language :: Python :: 3.4',
    #     'Programming Language :: Python :: 3.5',
    #     'Programming Language :: Python :: 3.6',
    # ],
    install_requires=[
        'MySQL-python>=1.2.3',
        'pyyaml>=3.12',
    ],
)
