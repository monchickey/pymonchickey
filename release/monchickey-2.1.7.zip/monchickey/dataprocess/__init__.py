# coding=utf-8
# import * 会导入指定模块中所依赖的所有模块 而比如import DataExtract则只会导入这个类 不会导入所依赖的其他模块
from DataCompute import DataCompute
from DataExtract import DataExtract
from DataConversion import *