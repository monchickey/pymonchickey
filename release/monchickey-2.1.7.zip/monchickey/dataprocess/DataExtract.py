# -*- coding:utf-8 -*-

# 数据抽取类，一般从很多字符串中获取有用的数据

class DataExtract(object):

    def __init__(self, args):
        self.name = args
		