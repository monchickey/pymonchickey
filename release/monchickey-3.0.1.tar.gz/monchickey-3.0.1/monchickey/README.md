# Python类库 - monchickey 3.0.1 20170925
## 适用版本 python 2.7.x

## 3.0.1 20170925
    - 数据库模块依赖由MySQL-python更新为PyMySQL
    - pymysql是MySQLdb模块更好的替代版,遵循数据库API 2.0规范,并同时支持python2和python3

## 3.0.0 20170702
    - 优化模块结构符合google python代码规范 更新daemon守护进程类为最新版本

## 2.2.0 20170623
    - 添加setup.py安装脚本 符合python模块安装标准

## 2.1.7 20170529
    - 添加计算文件md5,sha1,crc32值的方法

## 2.1.6 20170502
    ## 优化数据计算类方法结构 规范所有类的标准定义
