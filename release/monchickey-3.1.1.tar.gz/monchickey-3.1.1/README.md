# 基于 python2.7.x 的常用类库 monchickey 3.1.1 20171117

## 所需依赖
## 1. python-devel 安装:yum -y install python-devel或者rpm包安装
## 2. mysql-devel  安装:yum -y install mysql-devel或者rpm包安装
## 3. PyMySQL 下载地址:https://pypi.python.org/pypi/PyMySQL
## 4. PyYAML 下载地址:https://pypi.python.org/pypi/PyYAML
